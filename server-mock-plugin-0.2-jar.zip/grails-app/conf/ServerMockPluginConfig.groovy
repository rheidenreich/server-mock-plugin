mock.filesource = "${basedir}/grails-app/domain"
mock.enabled = true