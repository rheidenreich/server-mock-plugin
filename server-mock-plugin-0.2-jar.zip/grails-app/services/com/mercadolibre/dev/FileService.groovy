package com.mercadolibre.dev

class FileService {

    static transactional = true

    def serviceMethod() {

    }
}
