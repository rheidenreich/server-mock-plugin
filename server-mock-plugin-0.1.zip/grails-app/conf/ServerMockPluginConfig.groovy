mock.filesource = "${basedir}/grails-app/domain"
//mock.serverPrefix = "/mocks"
mock = {
	filesourceX = "X"
	filesource = "/home/fkorssjoen/cmgSell/grails-app/domainX"
	}
