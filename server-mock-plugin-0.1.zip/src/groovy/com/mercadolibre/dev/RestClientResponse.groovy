package com.mercadolibre.dev
public class RestClientResponse {

	def responseCode
	def responseContent
}

